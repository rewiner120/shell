/******************************************************
Insert buffer global types

(c) 1997 Innobase Oy

Created 7/29/1997 Heikki Tuuri
*******************************************************/

#ifndef ibuf0types_h
#define ibuf0types_h

typedef struct ibuf_data_struct	ibuf_data_t;
typedef	struct ibuf_struct	ibuf_t;

#endif
